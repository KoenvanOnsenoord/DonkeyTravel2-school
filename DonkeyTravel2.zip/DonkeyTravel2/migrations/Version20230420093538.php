<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20230420093538 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE booking ADD donkey_adventure_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE booking ADD CONSTRAINT FK_E00CEDDE2D63E894 FOREIGN KEY (donkey_adventure_id) REFERENCES donkey_adventure (id)');
        $this->addSql('CREATE INDEX IDX_E00CEDDE2D63E894 ON booking (donkey_adventure_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE booking DROP FOREIGN KEY FK_E00CEDDE2D63E894');
        $this->addSql('DROP INDEX IDX_E00CEDDE2D63E894 ON booking');
        $this->addSql('ALTER TABLE booking DROP donkey_adventure_id');
    }
}
