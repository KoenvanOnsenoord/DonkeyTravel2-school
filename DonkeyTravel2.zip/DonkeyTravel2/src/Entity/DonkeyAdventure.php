<?php

namespace App\Entity;

use App\Repository\DonkeyAdventureRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: DonkeyAdventureRepository::class)]
class DonkeyAdventure
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(length: 255)]
    private ?string $start_location = null;

    #[ORM\Column(length: 255)]
    private ?string $end_location = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $days = null;

    #[ORM\Column(length: 255)]
    private ?string $description = null;

    #[ORM\OneToMany(mappedBy: 'donkeyAdventure', targetEntity: Booking::class)]
    private Collection $Booking;

    public function __construct()
    {
        $this->Booking = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getStartLocation(): ?string
    {
        return $this->start_location;
    }

    public function setStartLocation(string $start_location): self
    {
        $this->start_location = $start_location;

        return $this;
    }

    public function getEndLocation(): ?string
    {
        return $this->end_location;
    }

    public function setEndLocation(string $end_location): self
    {
        $this->end_location = $end_location;

        return $this;
    }

    public function getDays(): ?\DateTimeInterface
    {
        return $this->days;
    }

    public function setDays(\DateTimeInterface $days): self
    {
        $this->days = $days;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return Collection<int, Booking>
     */
    public function getBooking(): Collection
    {
        return $this->Booking;
    }

    public function addBooking(Booking $booking): self
    {
        if (!$this->Booking->contains($booking)) {
            $this->Booking->add($booking);
            $booking->setDonkeyAdventure($this);
        }

        return $this;
    }

    public function removeBooking(Booking $booking): self
    {
        if ($this->Booking->removeElement($booking)) {
            // set the owning side to null (unless already changed)
            if ($booking->getDonkeyAdventure() === $this) {
                $booking->setDonkeyAdventure(null);
            }
        }

        return $this;
    }
}
